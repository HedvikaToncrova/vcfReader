#define BOOST_TEST_MAIN
#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>

#include "vcfData.hpp"

BOOST_AUTO_TEST_CASE( test1 )
{
    BOOST_CHECK( 2 == 2);
}
